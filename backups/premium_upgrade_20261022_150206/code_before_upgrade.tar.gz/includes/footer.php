<?php
/**
 * Footer Component — Minimal Editorial Full-Width Dark Footer (Zevyon-Inspired)
 */

if (!defined('ZAFFRAN_APP')) {
    exit('Direct access not permitted');
}

$storeSettings = getStoreSettings();
?>
  <!-- FULL-WIDTH DARK PROFESSIONAL FOOTER -->
  <footer class="site-footer" id="contact">
    <div class="container">
      <div class="footer-main-grid">
        
        <!-- Column 1: Brand Essence -->
        <div class="footer-col">
          <div class="footer-brand-title">ZAFFRAN</div>
          <span class="footer-brand-tagline">Pure Botanicals &amp; Artisanal Scents</span>
          <p class="footer-brand-bio">
            Dedicated to botanical provenance and ethical harvesting. We bring you pure Himalayan Shilajit, Kashmiri Super Negin saffron, artisanal perfumes, and bulk perfume oil concentrates for independent brand creators.
          </p>
        </div>

        <!-- Column 2: Categories -->
        <div class="footer-col">
          <h3 class="footer-heading">Collections</h3>
          <ul class="footer-links-list">
            <li><a href="shop.php?category=perfume">Artisanal Perfumes</a></li>
            <li><a href="shop.php?category=shilajit">Himalayan Shilajit</a></li>
            <li><a href="shop.php?category=zaffran">Royal Zaffran</a></li>
            <li><a href="category.php?slug=perfume-oils">Perfume Oil Supply</a></li>
            <li><a href="shop.php">All Collections</a></li>
          </ul>
        </div>

        <!-- Column 3: Useful Links -->
        <div class="footer-col" id="about-nav">
          <h3 class="footer-heading">Quick Links</h3>
          <ul class="footer-links-list">
            <li><a href="index.php#business-opportunity">Business Setup</a></li>
            <li><a href="index.php#faq">Frequently Asked Questions</a></li>
            <li><a href="index.php#why-us">Why Choose Zaffran</a></li>
            <li><a href="cart.php">Shopping Cart</a></li>
            <li><a href="checkout.php">Secure Checkout</a></li>
          </ul>
        </div>

        <!-- Column 4: Contact & Inquiries -->
        <div class="footer-col">
          <h3 class="footer-heading">Support &amp; Inquiries</h3>
          <div class="footer-contact-block">
            <div class="footer-contact-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
              </svg>
              <span><?php echo htmlspecialchars($storeSettings['store_address'] ?? 'Circular Road, Kot Addu, Punjab, Pakistan'); ?></span>
            </div>
            <div class="footer-contact-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
              </svg>
              <span><?php echo htmlspecialchars($storeSettings['store_phone'] ?? '0304-1202111'); ?></span>
            </div>
            <div class="footer-contact-item">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
              </svg>
              <span><?php echo htmlspecialchars($storeSettings['store_email'] ?? 'sales@zaffran.local'); ?></span>
            </div>
          </div>
        </div>

      </div>

      <!-- Bottom Bar -->
      <div class="footer-bottom-bar">
        <div>
          &copy; <?php echo date('Y'); ?> Zaffran. All rights reserved. Original Brand Identity.
        </div>
        <div class="footer-bottom-links">
          <a href="category.php?slug=perfume-oils">B2B Fragrance Supply</a>
          <a href="shop.php">Shop Now</a>
          <a href="checkout.php">Order Online</a>
        </div>
      </div>
    </div>
  </footer>

  <!-- Reusable Modular Scripts -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/hero.js"></script>
</body>
</html>
