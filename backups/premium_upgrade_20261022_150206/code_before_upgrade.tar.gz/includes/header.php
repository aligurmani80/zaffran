<?php
/**
 * Header & Navigation Component
 * Zaffran Store — Minimalist Editorial Navigation (Inspired by Zevyon)
 */

if (!defined('ZAFFRAN_APP')) {
    exit('Direct access not permitted');
}

require_once __DIR__ . '/../config/auth.php';

$announcements = getAnnouncements();
$cartCount = getCartCount();
$storeSettings = getStoreSettings();
$csrfToken = getCsrfToken();
$isAuthenticated = CustomerAuth::isAuthenticated();
$customer = $isAuthenticated ? CustomerAuth::getCustomer() : null;

// Determine relative base path for links when inside /account/ subdirectory
$isSubdir = (basename(dirname($_SERVER['PHP_SELF'])) === 'account');
$basePrefix = $isSubdir ? '../' : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="<?php echo htmlspecialchars($csrfToken); ?>">
  <title><?php echo htmlspecialchars($pageTitle ?? 'Zaffran | Pure Botanicals, Artisanal Fragrances & Essence Oils'); ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($pageDescription ?? 'Discover handcrafted luxury perfumes, authentic Himalayan Shilajit, pure Super Negin Zaffran, and premium perfume oils.'); ?>">

  <!-- Google Fonts: Playfair Display, Plus Jakarta Sans, Cinzel -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700&family=Playfair+Display:ital,wght@0,500;0,600;0,700;0,800;1,500;1,700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Shared CSS Variables & Core Styles -->
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/variables.css">
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/header.css">
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/hero.css">
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/sections.css">
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/shop.css">
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/cart_checkout.css">
  <link rel="stylesheet" href="<?php echo $basePrefix; ?>assets/css/auth.css">
</head>
<body>

  <!-- 1. SLIM BLACK ANNOUNCEMENT BAR (Top of Page) -->
  <?php if (!empty($announcements)): ?>
    <?php $multiAnnouncements = (count($announcements) > 1); ?>
    <aside class="announcement-bar" aria-label="Store Announcement">
      <div class="container announcement-container">
        <?php if ($multiAnnouncements): ?>
          <button class="announcement-nav-btn announcement-prev" aria-label="Previous announcement" type="button">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
          </button>
        <?php endif; ?>

        <div class="announcement-slides">
          <?php foreach ($announcements as $index => $item): ?>
            <div class="announcement-item <?php echo $index === 0 ? 'active' : ''; ?>">
              <?php if (!empty($item['title'])): ?>
                <span class="announcement-badge"><?php echo htmlspecialchars($item['title']); ?></span>
              <?php endif; ?>
              <span class="announcement-text"><?php echo htmlspecialchars($item['message'] ?? ''); ?></span>
              <?php if (!empty($item['link'])): ?>
                <a href="<?php echo $basePrefix . htmlspecialchars($item['link']); ?>" class="announcement-link">Discover &rarr;</a>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>

        <?php if ($multiAnnouncements): ?>
          <button class="announcement-nav-btn announcement-next" aria-label="Next announcement" type="button">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </button>
        <?php endif; ?>
      </div>
    </aside>
  <?php endif; ?>

  <!-- 2. MAIN MINIMAL WHITE NAVIGATION BAR -->
  <header class="site-header" id="site-header">
    <div class="container header-container">
      
      <!-- Mobile Header Order: Left Hamburger, Center Logo, Right Search & Cart -->
      <!-- Mobile Hamburger Button (Left on Mobile) -->
      <button class="mobile-nav-toggle" id="mobile-nav-toggle" aria-label="Toggle navigation menu" aria-expanded="false" aria-controls="mobile-drawer" type="button">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
      </button>

      <!-- Brand Logo Area -->
      <a href="<?php echo $basePrefix; ?>index.php" class="brand-logo" aria-label="Zaffran Home">
        <div class="brand-symbol" aria-hidden="true">Z</div>
        <div class="brand-text">
          <span class="brand-title">ZAFFRAN</span>
          <span class="brand-tagline">Artisanal Botanicals</span>
        </div>
      </a>

      <!-- Desktop Navigation Links (Zevyon-Style Structure) -->
      <nav class="nav-menu-wrap" aria-label="Main Navigation">
        <ul class="nav-menu">
          <li><a href="<?php echo $basePrefix; ?>index.php" class="nav-link <?php echo (basename($_SERVER['PHP_SELF']) === 'index.php') ? 'active' : ''; ?>">Home</a></li>
          <li><a href="<?php echo $basePrefix; ?>index.php#business-opportunity" class="nav-link">Business Setup</a></li>
          <li><a href="<?php echo $basePrefix; ?>index.php#about" class="nav-link">About</a></li>
          <li><a href="<?php echo $basePrefix; ?>index.php#contact" class="nav-link">Contact</a></li>
        </ul>
      </nav>

      <!-- Action Utilities: Search, Account, Cart, Mobile Toggle -->
      <div class="header-actions">
        <!-- Search Trigger -->
        <button type="button" class="action-btn js-search-trigger" aria-label="Open search dialog" title="Search products">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="8"></circle>
            <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
        </button>

        <!-- Customer Account / Sign In Action -->
        <?php if ($isAuthenticated && $customer): ?>
          <a href="<?php echo $basePrefix; ?>account.php" class="action-btn" aria-label="My Account" title="My Account (<?php echo htmlspecialchars($customer['name']); ?>)">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
          </a>
        <?php else: ?>
          <a href="<?php echo $basePrefix; ?>login.php" class="action-btn" aria-label="Sign In" title="Sign In / Register">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
              <polyline points="10 17 15 12 10 7"></polyline>
              <line x1="15" y1="12" x2="3" y2="12"></line>
            </svg>
          </a>
        <?php endif; ?>

        <!-- Cart Trigger -->
        <a href="<?php echo $basePrefix; ?>cart.php" class="action-btn" aria-label="Shopping Cart" title="View Cart">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <path d="M16 10a4 4 0 0 1-8 0"></path>
          </svg>
          <span class="cart-count-badge" style="<?php echo $cartCount > 0 ? '' : 'display:none;'; ?>">
            <?php echo $cartCount; ?>
          </span>
        </a>
      </div>

    </div>
  </header>

  <!-- Interactive Search Modal Overlay -->
  <div class="search-overlay" id="search-overlay" aria-hidden="true">
    <div class="search-dialog" role="dialog" aria-modal="true" aria-labelledby="search-dialog-title">
      <div class="search-dialog-header">
        <h3 class="search-dialog-title" id="search-dialog-title">Search Botanical Catalog</h3>
        <button type="button" class="search-close-btn js-search-close" aria-label="Close search dialog">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>

      <form action="<?php echo $basePrefix; ?>shop.php" method="GET" class="search-form">
        <div class="search-input-wrap">
          <input type="search" name="q" class="search-input-field" placeholder="Search by name, scent or botanical..." required autocomplete="off">
          <button type="submit" class="search-submit-btn" aria-label="Submit search">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"></circle>
              <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
            </svg>
          </button>
        </div>
      </form>

      <div class="search-quick-tags">
        <span style="color:var(--color-text-muted); font-size:0.8125rem;">Popular searches:</span>
        <a href="<?php echo $basePrefix; ?>shop.php?category=perfume" class="search-quick-tag">Perfumes</a>
        <a href="<?php echo $basePrefix; ?>shop.php?category=shilajit" class="search-quick-tag">Himalayan Shilajit</a>
        <a href="<?php echo $basePrefix; ?>shop.php?category=zaffran" class="search-quick-tag">Super Negin Saffron</a>
        <a href="<?php echo $basePrefix; ?>category.php?slug=perfume-oils" class="search-quick-tag">Perfume Oils (B2B)</a>
      </div>
    </div>
  </div>

  <!-- Mobile Navigation Drawer -->
  <div class="mobile-drawer-backdrop" id="mobile-drawer-backdrop" aria-hidden="true"></div>
  <aside class="mobile-drawer" id="mobile-drawer" role="dialog" aria-modal="true" aria-label="Mobile Navigation Drawer">
    <div class="mobile-drawer-header">
      <div class="brand-logo">
        <div class="brand-symbol" aria-hidden="true">Z</div>
        <div class="brand-text">
          <span class="brand-title" style="font-size:1.25rem;">ZAFFRAN</span>
          <span class="brand-tagline">Artisanal Botanicals</span>
        </div>
      </div>
      <button class="drawer-close-btn" id="drawer-close-btn" aria-label="Close menu" type="button">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <ul class="mobile-drawer-menu">
      <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>index.php" class="<?php echo (basename($_SERVER['PHP_SELF']) === 'index.php') ? 'active' : ''; ?>">Home</a></li>
      <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>shop.php" class="<?php echo (basename($_SERVER['PHP_SELF']) === 'shop.php') ? 'active' : ''; ?>">Shop All Collections</a></li>
      
      <!-- Category Quick Links in Drawer -->
      <li class="mobile-nav-item sub-category-item"><a href="<?php echo $basePrefix; ?>shop.php?category=perfume">&mdash; Artisanal Perfumes</a></li>
      <li class="mobile-nav-item sub-category-item"><a href="<?php echo $basePrefix; ?>shop.php?category=shilajit">&mdash; Pure Himalayan Shilajit</a></li>
      <li class="mobile-nav-item sub-category-item"><a href="<?php echo $basePrefix; ?>shop.php?category=zaffran">&mdash; Super Negin Saffron</a></li>
      <li class="mobile-nav-item sub-category-item"><a href="<?php echo $basePrefix; ?>category.php?slug=perfume-oils">&mdash; Perfume Oils &amp; Attar</a></li>

      <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>cart.php">Shopping Bag (<?php echo $cartCount; ?>)</a></li>
      
      <?php if ($isAuthenticated && $customer): ?>
        <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>account.php">My Account (<?php echo htmlspecialchars($customer['name']); ?>)</a></li>
        <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>account/orders.php">My Orders</a></li>
        <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>logout.php" style="color:#dc2626;">Sign Out</a></li>
      <?php else: ?>
        <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>login.php" style="color:var(--color-saffron-600); font-weight:700;">Sign In / Register with OTP</a></li>
      <?php endif; ?>

      <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>index.php#business-opportunity">Business Setup</a></li>
      <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>index.php#about">Our Story</a></li>
      <li class="mobile-nav-item"><a href="<?php echo $basePrefix; ?>index.php#contact">Contact</a></li>
    </ul>

    <div class="mobile-drawer-footer">
      <p class="mobile-drawer-contact">
        <strong>Direct Inquiries:</strong><br>
        <?php echo htmlspecialchars($storeSettings['store_phone'] ?? '0304-1202111'); ?>
      </p>
      <a href="<?php echo $basePrefix; ?>category.php?slug=perfume-oils" class="btn btn-primary" style="width:100%; min-height:48px;">Perfume Oil Inquiry</a>
    </div>
  </aside>
