const http = require('http');

async function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    }).on('error', reject);
  });
}

function sendCommand(ws, method, params = {}) {
  return new Promise((resolve) => {
    const id = Math.floor(Math.random() * 1000000);
    const handler = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id === id) {
        ws.removeEventListener('message', handler);
        resolve(msg.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id, method, params }));
  });
}

async function testViewport(ws, width, height, pageUrl) {
  await sendCommand(ws, 'Page.navigate', { url: pageUrl });
  await new Promise(r => setTimeout(r, 1000));

  await sendCommand(ws, 'Emulation.setDeviceMetricsOverride', {
    width: width,
    height: height,
    deviceScaleFactor: 1,
    mobile: width < 1024
  });
  await new Promise(r => setTimeout(r, 500));

  const evalRes = await sendCommand(ws, 'Runtime.evaluate', {
    expression: `
      (() => {
        const grid = document.querySelector('.product-grid');
        if (!grid) return { error: 'No product grid found' };
        const computed = window.getComputedStyle(grid);
        const cards = Array.from(grid.querySelectorAll('.product-card'));
        const cols = computed.gridTemplateColumns.split(' ').length;
        const colDef = computed.gridTemplateColumns;
        const gap = computed.gap;
        const docWidth = document.documentElement.scrollWidth;
        const bodyWidth = document.body.scrollWidth;
        const clientWidth = document.documentElement.clientWidth;
        const hasHorizontalScroll = docWidth > clientWidth || bodyWidth > clientWidth;
        
        const cardBoxes = cards.map((c, i) => {
          const rect = c.getBoundingClientRect();
          const title = c.querySelector('.product-title')?.innerText?.trim()?.replace(/\\n/g, ' ');
          const price = c.querySelector('.product-price-box')?.innerText?.trim()?.replace(/\\n/g, ' ');
          const btn = c.querySelector('.js-add-to-cart');
          return {
            index: i,
            x: Math.round(rect.x),
            y: Math.round(rect.y),
            width: Math.round(rect.width),
            height: Math.round(rect.height),
            title: title ? title.slice(0, 20) : '',
            hasAddToCart: !!btn
          };
        });

        const rows = {};
        cardBoxes.forEach(c => {
          const rowKey = Math.round(c.y / 20) * 20;
          if (!rows[rowKey]) rows[rowKey] = [];
          rows[rowKey].push(c);
        });

        const rowCounts = Object.values(rows).map(r => r.length);

        return {
          viewport: ${width},
          colsCount: cols,
          colDef,
          gap,
          cardsCount: cards.length,
          rowCounts,
          hasHorizontalScroll,
          docWidth,
          clientWidth,
          cardWidths: cardBoxes.slice(0, 4).map(c => c.width)
        };
      })()
    `,
    returnByValue: true
  });

  return evalRes.result.value;
}

async function run() {
  const tabs = await getJson('http://127.0.0.1:9333/json');
  const targetTab = tabs.find(t => t.type === 'page');
  if (!targetTab) {
    console.error('No page tab found');
    process.exit(1);
  }

  const ws = new WebSocket(targetTab.webSocketDebuggerUrl);
  await new Promise(res => ws.addEventListener('open', res));

  await sendCommand(ws, 'Page.enable');
  await sendCommand(ws, 'DOM.enable');

  const testWidths = [320, 360, 390, 430, 768, 1024, 1440];
  const pages = [
    { name: 'Home Page', url: 'http://localhost/zaffran/index.php' },
    { name: 'Shop Page', url: 'http://localhost/zaffran/shop.php' },
    { name: 'Category Page', url: 'http://localhost/zaffran/category.php?slug=saffron' },
    { name: 'Product Details (Related)', url: 'http://localhost/zaffran/product.php?slug=kashmir-super-mongra-saffron' }
  ];

  for (const page of pages) {
    console.log(`\n======================================================`);
    console.log(`TESTING: ${page.name} (${page.url})`);
    console.log(`======================================================`);
    for (const w of testWidths) {
      const res = await testViewport(ws, w, 900, page.url);
      console.log(`[${w}px]: Cols=${res.colsCount} | Rows=${JSON.stringify(res.rowCounts)} | Gap=${res.gap} | HScroll=${res.hasHorizontalScroll} | CardWidths=${JSON.stringify(res.cardWidths)}`);
    }
  }

  ws.close();
  process.exit(0);
}

run().catch(console.error);
