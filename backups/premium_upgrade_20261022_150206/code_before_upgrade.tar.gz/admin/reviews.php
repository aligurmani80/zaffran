<?php
/**
 * Zaffran Admin Panel — Customer Reviews & WhatsApp Feedback Screenshot Management
 */
define('ZAFFRAN_APP', true);
$pageTitle = 'Customer Reviews / WhatsApp Proof';
require_once __DIR__ . '/header.php';

$db = getDbConnection();

$successMsg = '';
$errorMsg = '';

// Products for optional tagging
$products = $db->query("SELECT id, name FROM products WHERE is_active = 1 ORDER BY name ASC")->fetchAll();

// Handle Screenshot Proof Upload / Edit / Status Toggle / Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!validateAdminCsrfToken($token)) {
        $errorMsg = 'Security validation failed.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'upload_proof') {
            $customerName = trim(strip_tags($_POST['customer_display_name'] ?? ''));
            $productId = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
            $caption = trim(strip_tags($_POST['caption'] ?? ''));
            $rating = !empty($_POST['rating']) ? min(5, max(1, (int)$_POST['rating'])) : null;
            $order = (int)($_POST['display_order'] ?? 0);
            $isPublished = !empty($_POST['is_published']) ? 1 : 0;
            $privacyAgreed = !empty($_POST['privacy_confirmed']);

            if (!$privacyAgreed && $isPublished) {
                $errorMsg = 'Please verify that private customer phone numbers/addresses have been redacted before publishing.';
            } elseif (empty($_FILES['proof_screenshot']['name'])) {
                $errorMsg = 'Please select a WhatsApp screenshot image to upload.';
            } else {
                $upload = handleImageUpload($_FILES['proof_screenshot'], 'whatsapp_proofs');
                if (!$upload['success']) {
                    $errorMsg = 'Screenshot upload failed: ' . $upload['error'];
                } else {
                    try {
                        $imagePath = $upload['path'];
                        $stmt = $db->prepare("INSERT INTO whatsapp_proofs (image_path, customer_display_name, product_id, rating, caption, is_published, display_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
                        $stmt->execute([$imagePath, $customerName, $productId, $rating, $caption, $isPublished, $order]);
                        $newId = $db->lastInsertId();
                        logAdminAudit('upload_whatsapp_proof', 'whatsapp_proof', (string)$newId, "Uploaded review screenshot for '{$customerName}' (Published: {$isPublished})");
                        $successMsg = 'WhatsApp feedback screenshot uploaded successfully.' . ($isPublished ? ' (Published to homepage)' : ' (Saved as Draft)');
                    } catch (Exception $e) {
                        $errorMsg = 'Database error: ' . $e->getMessage();
                    }
                }
            }
        } elseif ($action === 'edit_proof') {
            $proofId = (int)($_POST['proof_id'] ?? 0);
            $customerName = trim(strip_tags($_POST['customer_display_name'] ?? ''));
            $productId = !empty($_POST['product_id']) ? (int)$_POST['product_id'] : null;
            $caption = trim(strip_tags($_POST['caption'] ?? ''));
            $rating = !empty($_POST['rating']) ? min(5, max(1, (int)$_POST['rating'])) : null;
            $order = (int)($_POST['display_order'] ?? 0);
            $isPublished = !empty($_POST['is_published']) ? 1 : 0;

            if ($proofId > 0) {
                $cur = $db->prepare("SELECT * FROM whatsapp_proofs WHERE id = ?");
                $cur->execute([$proofId]);
                $proof = $cur->fetch();

                if ($proof) {
                    $imagePath = $proof['image_path'];
                    if (!empty($_FILES['proof_screenshot']['name'])) {
                        $upload = handleImageUpload($_FILES['proof_screenshot'], 'whatsapp_proofs');
                        if ($upload['success']) {
                            $imagePath = $upload['path'];
                        }
                    }

                    try {
                        $upd = $db->prepare("UPDATE whatsapp_proofs SET image_path = ?, customer_display_name = ?, product_id = ?, rating = ?, caption = ?, is_published = ?, display_order = ?, updated_at = NOW() WHERE id = ?");
                        $upd->execute([$imagePath, $customerName, $productId, $rating, $caption, $isPublished, $order, $proofId]);
                        logAdminAudit('edit_whatsapp_proof', 'whatsapp_proof', (string)$proofId, "Updated proof #{$proofId}");
                        $successMsg = 'Review screenshot details updated successfully.';
                    } catch (Exception $e) {
                        $errorMsg = 'Database error: ' . $e->getMessage();
                    }
                }
            }
        } elseif ($action === 'toggle_publish') {
            $proofId = (int)($_POST['proof_id'] ?? 0);
            if ($proofId > 0) {
                $cur = $db->prepare("SELECT is_published, customer_display_name FROM whatsapp_proofs WHERE id = ?");
                $cur->execute([$proofId]);
                $row = $cur->fetch();
                if ($row) {
                    $newStatus = $row['is_published'] ? 0 : 1;
                    $db->prepare("UPDATE whatsapp_proofs SET is_published = ?, updated_at = NOW() WHERE id = ?")->execute([$newStatus, $proofId]);
                    logAdminAudit('toggle_whatsapp_proof', 'whatsapp_proof', (string)$proofId, "Changed publish status to " . ($newStatus ? 'Published' : 'Unpublished'));
                    $successMsg = "Screenshot visibility updated.";
                }
            }
        } elseif ($action === 'delete_proof') {
            $proofId = (int)($_POST['proof_id'] ?? 0);
            if ($proofId > 0) {
                $db->prepare("DELETE FROM whatsapp_proofs WHERE id = ?")->execute([$proofId]);
                logAdminAudit('delete_whatsapp_proof', 'whatsapp_proof', (string)$proofId, 'Removed WhatsApp feedback record');
                $successMsg = 'Screenshot review deleted.';
            }
        }
    }
}

// Fetch WhatsApp proofs with product name
$proofs = $db->query("SELECT wp.*, p.name as product_name FROM whatsapp_proofs wp LEFT JOIN products p ON wp.product_id = p.id ORDER BY wp.display_order ASC, wp.id DESC")->fetchAll();
$csrfToken = getAdminCsrfToken();
?>

<?php if (!empty($successMsg)): ?>
  <div class="notice-box notice-success">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
    <div><?php echo htmlspecialchars($successMsg); ?></div>
  </div>
<?php endif; ?>

<?php if (!empty($errorMsg)): ?>
  <div class="notice-box notice-error">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
    <div><?php echo htmlspecialchars($errorMsg); ?></div>
  </div>
<?php endif; ?>

<!-- PRIVACY & INTEGRITY NOTICE -->
<div class="notice-box notice-info" style="margin-bottom: 24px;">
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
  <div>
    <strong>Genuine WhatsApp Social Proof Guidelines:</strong><br>
    Only upload authentic chat screenshots received from real buyers. Please ensure customer phone numbers and residential addresses are blurred/redacted before publishing to protect privacy.
  </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
  
  <!-- WhatsApp Screenshots List -->
  <div class="admin-card">
    <div class="admin-card-header">
      <div class="admin-card-title">WhatsApp Customer Proofs (<?php echo count($proofs); ?>)</div>
      <a href="../index.php#reviews" target="_blank" class="btn btn-secondary btn-sm">Preview on Homepage &rarr;</a>
    </div>
    <div class="admin-card-body" style="padding: 0;">
      <div class="table-responsive">
        <table class="admin-table">
          <thead>
            <tr>
              <th style="width: 70px;">Preview</th>
              <th>Customer Label</th>
              <th>Product Tag</th>
              <th>Rating</th>
              <th>Caption / Excerpt</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($proofs)): ?>
              <tr>
                <td colspan="7" style="text-align: center; padding: 36px; color: var(--admin-text-muted);">
                  No WhatsApp screenshot feedback uploaded yet. Upload a screenshot on the right.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($proofs as $p): ?>
                <tr>
                  <td>
                    <div style="width: 50px; height: 75px; border-radius: 6px; overflow: hidden; background: #EEE; border: 1px solid var(--admin-card-border); cursor: pointer;" onclick="openAdminLightbox('<?php echo htmlspecialchars('../' . $p['image_path']); ?>')">
                      <img src="../<?php echo htmlspecialchars($p['image_path']); ?>" alt="Proof" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='../assets/images/logo.jpg'">
                    </div>
                  </td>
                  <td>
                    <div style="font-weight: 600; color: var(--admin-forest);">
                      <?php echo htmlspecialchars($p['customer_display_name'] ?: 'Verified Customer'); ?>
                    </div>
                    <div style="font-size: 11px; color: var(--admin-text-muted);">
                      Sequence: #<?php echo (int)$p['display_order']; ?>
                    </div>
                  </td>
                  <td>
                    <?php if (!empty($p['product_name'])): ?>
                      <span class="badge" style="background: #F0F2F1; color: var(--admin-forest);">
                        <?php echo htmlspecialchars($p['product_name']); ?>
                      </span>
                    <?php else: ?>
                      <span style="color: var(--admin-text-muted); font-size: 12px;">General Store</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if (!empty($p['rating'])): ?>
                      <span style="color: var(--admin-saffron); font-size: 13px;">
                        <?php echo str_repeat('★', (int)$p['rating']); ?>
                      </span>
                    <?php else: ?>
                      <span style="color: var(--admin-text-muted); font-size: 12px;">—</span>
                    <?php endif; ?>
                  </td>
                  <td style="font-size: 12px; max-width: 220px; line-height: 1.4;">
                    <?php echo htmlspecialchars($p['caption'] ?: '—'); ?>
                  </td>
                  <td>
                    <?php if (!empty($p['is_published'])): ?>
                      <span class="badge badge-active">Published</span>
                    <?php else: ?>
                      <span class="badge badge-pending">Draft / Hidden</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                      <button type="button" class="btn btn-secondary btn-sm" onclick='editProof(<?php echo json_encode($p); ?>)'>
                        Edit
                      </button>
                      
                      <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <input type="hidden" name="action" value="toggle_publish">
                        <input type="hidden" name="proof_id" value="<?php echo $p['id']; ?>">
                        <button type="submit" class="btn btn-secondary btn-sm">
                          <?php echo !empty($p['is_published']) ? 'Unpublish' : 'Publish'; ?>
                        </button>
                      </form>

                      <form method="POST" onsubmit="return confirm('Delete this screenshot review?');">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <input type="hidden" name="action" value="delete_proof">
                        <input type="hidden" name="proof_id" value="<?php echo $p['id']; ?>">
                        <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--admin-danger);">
                          &times;
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Upload / Edit Form -->
  <div class="admin-card">
    <div class="admin-card-header">
      <div class="admin-card-title" id="formCardTitle">Upload WhatsApp Screenshot</div>
    </div>
    <div class="admin-card-body">
      
      <form method="POST" enctype="multipart/form-data" id="proofForm">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
        <input type="hidden" name="action" id="formAction" value="upload_proof">
        <input type="hidden" name="proof_id" id="proofId" value="">

        <div class="form-group">
          <label class="form-label" for="proof_screenshot">Screenshot Image <span class="required" id="fileRequired">*</span></label>
          <input type="file" id="proof_screenshot" name="proof_screenshot" class="form-control" accept="image/jpeg,image/png,image/webp" onchange="previewUploadImage(this)">
          <div class="form-help">Formats: JPG, PNG, WebP (Max 5MB). High clarity preserved.</div>
          
          <div id="imagePreviewBox" style="margin-top: 10px; display: none;">
            <div style="width: 100px; height: 150px; border-radius: 6px; overflow: hidden; border: 1px solid var(--admin-card-border); background: #EEE;">
              <img id="imgPreviewTarget" src="#" alt="Selected preview" style="width: 100%; height: 100%; object-fit: contain;">
            </div>
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="customer_name">Customer Display Label</label>
          <input type="text" id="customer_name" name="customer_display_name" class="form-control" placeholder="E.g. Bilal A. (Lahore) or Dr. Naveed">
          <div class="form-help">Use safe, non-identifying name or city without phone number.</div>
        </div>

        <div class="form-group">
          <label class="form-label" for="product_id">Associated Product (Optional)</label>
          <select id="product_id" name="product_id" class="form-control">
            <option value="">General Store Experience</option>
            <?php foreach ($products as $pr): ?>
              <option value="<?php echo $pr['id']; ?>"><?php echo htmlspecialchars($pr['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="rating">Genuine Rating (Optional)</label>
          <select id="rating" name="rating" class="form-control">
            <option value="">No Star Rating (Unspecified)</option>
            <option value="5">5 Stars (★★★★★)</option>
            <option value="4">4 Stars (★★★★☆)</option>
            <option value="3">3 Stars (★★★☆☆)</option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label" for="caption">Review Caption / Key Excerpt</label>
          <textarea id="caption" name="caption" class="form-control" rows="3" placeholder="Brief quote or highlight from customer feedback..."></textarea>
        </div>

        <div class="form-group">
          <label class="form-label" for="display_order">Display Sequence</label>
          <input type="number" id="display_order" name="display_order" class="form-control" value="0">
        </div>

        <div class="form-group" style="margin-top: 14px;">
          <label style="display: flex; align-items: flex-start; gap: 8px; font-size: 13px; cursor: pointer; color: var(--admin-forest);">
            <input type="checkbox" id="privacy_confirmed" name="privacy_confirmed" value="1" checked style="margin-top: 3px;">
            <span>I confirm phone numbers/addresses in this screenshot are redacted or authorized for marketing display.</span>
          </label>
        </div>

        <div class="form-group">
          <label style="display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer;">
            <input type="checkbox" id="is_published" name="is_published" value="1" checked>
            Publish to Homepage Gallery Immediately
          </label>
        </div>

        <div style="display: flex; gap: 8px; margin-top: 20px;">
          <button type="submit" class="btn btn-primary" id="submitBtn" style="flex: 1;">Save Screenshot Review</button>
          <button type="button" class="btn btn-secondary" id="resetBtn" style="display: none;" onclick="resetProofForm()">Cancel</button>
        </div>
      </form>

    </div>
  </div>

</div>

<!-- LIGHTBOX MODAL FOR ADMIN PREVIEW -->
<div id="adminLightboxModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 9999; align-items: center; justify-content: center; padding: 20px;" onclick="closeAdminLightbox()">
  <div style="position: relative; max-width: 90vw; max-height: 90vh;" onclick="event.stopPropagation()">
    <img id="adminLightboxImg" src="" style="max-width: 100%; max-height: 85vh; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
    <button type="button" style="position: absolute; top: -35px; right: 0; background: transparent; border: none; color: #FFF; font-size: 28px; cursor: pointer;" onclick="closeAdminLightbox()">&times;</button>
  </div>
</div>

<script>
function previewUploadImage(input) {
  const box = document.getElementById('imagePreviewBox');
  const target = document.getElementById('imgPreviewTarget');
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      target.src = e.target.result;
      box.style.display = 'block';
    }
    reader.readAsDataURL(input.files[0]);
  }
}

function openAdminLightbox(src) {
  document.getElementById('adminLightboxImg').src = src;
  document.getElementById('adminLightboxModal').style.display = 'flex';
}

function closeAdminLightbox() {
  document.getElementById('adminLightboxModal').style.display = 'none';
}

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') closeAdminLightbox();
});

function editProof(p) {
  document.getElementById('formCardTitle').textContent = 'Edit Review Proof #' + p.id;
  document.getElementById('formAction').value = 'edit_proof';
  document.getElementById('proofId').value = p.id;
  document.getElementById('customer_name').value = p.customer_display_name || '';
  document.getElementById('product_id').value = p.product_id || '';
  document.getElementById('rating').value = p.rating || '';
  document.getElementById('caption').value = p.caption || '';
  document.getElementById('display_order').value = p.display_order || '0';
  document.getElementById('is_published').checked = p.is_published == 1;
  document.getElementById('fileRequired').style.display = 'none';
  
  if (p.image_path) {
    document.getElementById('imgPreviewTarget').src = '../' + p.image_path;
    document.getElementById('imagePreviewBox').style.display = 'block';
  }

  document.getElementById('submitBtn').textContent = 'Update Screenshot Details';
  document.getElementById('resetBtn').style.display = 'inline-flex';
}

function resetProofForm() {
  document.getElementById('formCardTitle').textContent = 'Upload WhatsApp Screenshot';
  document.getElementById('formAction').value = 'upload_proof';
  document.getElementById('proofId').value = '';
  document.getElementById('proof_screenshot').value = '';
  document.getElementById('customer_name').value = '';
  document.getElementById('product_id').value = '';
  document.getElementById('rating').value = '';
  document.getElementById('caption').value = '';
  document.getElementById('display_order').value = '0';
  document.getElementById('is_published').checked = true;
  document.getElementById('fileRequired').style.display = 'inline';
  document.getElementById('imagePreviewBox').style.display = 'none';
  document.getElementById('submitBtn').textContent = 'Save Screenshot Review';
  document.getElementById('resetBtn').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
