<?php
/**
 * Zaffran Admin Panel — Announcement Bar Management
 */
define('ZAFFRAN_APP', true);
$pageTitle = 'Announcement Bar Management';
require_once __DIR__ . '/header.php';

$db = getDbConnection();

$successMsg = '';
$errorMsg = '';

// Handle Create / Edit / Toggle / Delete
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!validateAdminCsrfToken($token)) {
        $errorMsg = 'Security validation failed.';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'create_announcement') {
            $title = trim(strip_tags($_POST['title'] ?? ''));
            $message = trim(strip_tags($_POST['message'] ?? ''));
            $linkUrl = trim(filter_var($_POST['link_url'] ?? '', FILTER_SANITIZE_URL));
            $order = (int)($_POST['display_order'] ?? 0);
            $isActive = !empty($_POST['is_active']) ? 1 : 0;
            $bgColor = trim(strip_tags($_POST['bg_color'] ?? '#d4af37'));
            $textColor = trim(strip_tags($_POST['text_color'] ?? '#000000'));
            $displayType = in_array($_POST['display_type'] ?? '', ['scrolling', 'static']) ? $_POST['display_type'] : 'scrolling';

            if (empty($message)) {
                $errorMsg = 'Announcement message cannot be empty.';
            } else {
                try {
                    $stmt = $db->prepare("INSERT INTO announcements (title, message, link_url, is_active, display_order, bg_color, text_color, display_type, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
                    $stmt->execute([$title, $message, $linkUrl, $isActive, $order, $bgColor, $textColor, $displayType]);
                    $newId = $db->lastInsertId();
                    logAdminAudit('create_announcement', 'announcement', (string)$newId, "Created announcement: '{$title}'");
                    $successMsg = 'Announcement published successfully.';
                } catch (Exception $e) {
                    $errorMsg = 'Error saving announcement: ' . $e->getMessage();
                }
            }
        } elseif ($action === 'edit_announcement') {
            $annId = (int)($_POST['announcement_id'] ?? 0);
            $title = trim(strip_tags($_POST['title'] ?? ''));
            $message = trim(strip_tags($_POST['message'] ?? ''));
            $linkUrl = trim(filter_var($_POST['link_url'] ?? '', FILTER_SANITIZE_URL));
            $order = (int)($_POST['display_order'] ?? 0);
            $isActive = !empty($_POST['is_active']) ? 1 : 0;
            $bgColor = trim(strip_tags($_POST['bg_color'] ?? '#d4af37'));
            $textColor = trim(strip_tags($_POST['text_color'] ?? '#000000'));
            $displayType = in_array($_POST['display_type'] ?? '', ['scrolling', 'static']) ? $_POST['display_type'] : 'scrolling';

            if ($annId > 0 && !empty($message)) {
                try {
                    $stmt = $db->prepare("UPDATE announcements SET title = ?, message = ?, link_url = ?, is_active = ?, display_order = ?, bg_color = ?, text_color = ?, display_type = ?, updated_at = NOW() WHERE id = ?");
                    $stmt->execute([$title, $message, $linkUrl, $isActive, $order, $bgColor, $textColor, $displayType, $annId]);
                    logAdminAudit('edit_announcement', 'announcement', (string)$annId, "Updated announcement #{$annId}");
                    $successMsg = 'Announcement updated successfully.';
                } catch (Exception $e) {
                    $errorMsg = 'Error updating announcement: ' . $e->getMessage();
                }
            }
        } elseif ($action === 'toggle_active') {
            $annId = (int)($_POST['announcement_id'] ?? 0);
            if ($annId > 0) {
                $cur = $db->prepare("SELECT is_active, title FROM announcements WHERE id = ?");
                $cur->execute([$annId]);
                $row = $cur->fetch();
                if ($row) {
                    $newStatus = $row['is_active'] ? 0 : 1;
                    $db->prepare("UPDATE announcements SET is_active = ?, updated_at = NOW() WHERE id = ?")->execute([$newStatus, $annId]);
                    logAdminAudit('toggle_announcement', 'announcement', (string)$annId, "Toggled status to " . ($newStatus ? 'Active' : 'Inactive'));
                    $successMsg = "Announcement status updated.";
                }
            }
        } elseif ($action === 'delete_announcement') {
            $annId = (int)($_POST['announcement_id'] ?? 0);
            if ($annId > 0) {
                $db->prepare("DELETE FROM announcements WHERE id = ?")->execute([$annId]);
                logAdminAudit('delete_announcement', 'announcement', (string)$annId, 'Deleted announcement');
                $successMsg = 'Announcement removed.';
            }
        }
    }
}

// Fetch all announcements ordered by display_order
$announcements = $db->query("SELECT * FROM announcements ORDER BY display_order ASC, id DESC")->fetchAll();
$csrfToken = getAdminCsrfToken();
?>

<?php if (!empty($successMsg)): ?>
  <div class="notice-box notice-success">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
    <div><?php echo htmlspecialchars($successMsg); ?></div>
  </div>
<?php endif; ?>

<?php if (!empty($errorMsg)): ?>
  <div class="notice-box notice-error">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
    <div><?php echo htmlspecialchars($errorMsg); ?></div>
  </div>
<?php endif; ?>

<!-- LIVE VISUAL PREVIEW OF TOP STRIP -->
<div class="admin-card" style="margin-bottom: 24px;">
  <div class="admin-card-header">
    <div class="admin-card-title">Live Announcement Bar Preview (Storefront Replica)</div>
    <span style="font-size: 12px; color: var(--admin-text-muted);">Matches exactly how it renders at top of website</span>
  </div>
  <div class="admin-card-body" style="background: #111; padding: 14px 20px; border-radius: 0 0 var(--admin-radius) var(--admin-radius);">
    <div id="liveStripPreview" style="display: flex; align-items: center; justify-content: center; gap: 12px; color: #FFF; font-size: 13px; text-align: center; flex-wrap: wrap;">
      <span id="prevBadge" style="background: var(--admin-saffron); color: #000; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.5px;">Notice</span>
      <span id="prevMessage" style="color: #DDD;">Special Offer: 100% Pure Himalayan Shilajit, Imperial Zaffran &amp; Luxury Perfumes.</span>
      <a href="javascript:void(0)" id="prevLink" style="color: var(--admin-saffron); text-decoration: none; font-size: 12px; font-weight: 600;">Discover &rarr;</a>
    </div>
  </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
  
  <!-- Announcements List -->
  <div class="admin-card">
    <div class="admin-card-header">
      <div class="admin-card-title">Active &amp; Scheduled Announcements (<?php echo count($announcements); ?>)</div>
      <a href="../index.php" target="_blank" class="btn btn-secondary btn-sm">View Homepage &rarr;</a>
    </div>
    <div class="admin-card-body" style="padding: 0;">
      <div class="table-responsive">
        <table class="admin-table">
          <thead>
            <tr>
              <th style="width: 50px;">Order</th>
              <th>Badge Title</th>
              <th>Announcement Message</th>
              <th>Destination Link</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($announcements)): ?>
              <tr>
                <td colspan="6" style="text-align: center; padding: 36px; color: var(--admin-text-muted);">
                  No announcements found. Add one using the form on the right.
                </td>
              </tr>
            <?php else: ?>
              <?php foreach ($announcements as $ann): ?>
                <tr>
                  <td style="font-weight: 700; color: var(--admin-forest); text-align: center;">
                    <?php echo (int)($ann['display_order'] ?? 0); ?>
                  </td>
                  <td>
                    <?php if (!empty($ann['title'])): ?>
                      <span class="badge" style="background: var(--admin-saffron-light); color: var(--admin-saffron-dark); font-weight: 700;">
                        <?php echo htmlspecialchars($ann['title']); ?>
                      </span>
                    <?php else: ?>
                      <span style="color: var(--admin-text-muted); font-size: 12px;">(No badge)</span>
                    <?php endif; ?>
                  </td>
                  <td style="font-size: 13px; max-width: 280px; line-height: 1.4;">
                    <?php echo htmlspecialchars($ann['message']); ?>
                  </td>
                  <td style="font-size: 12px; font-family: monospace; color: var(--admin-sage);">
                    <?php echo htmlspecialchars($ann['link_url'] ?: '—'); ?>
                  </td>
                  <td>
                    <?php if (!empty($ann['is_active'])): ?>
                      <span class="badge badge-active">Live</span>
                    <?php else: ?>
                      <span class="badge badge-inactive">Disabled</span>
                    <?php endif; ?>
                  </td>
                  <td>
                    <div style="display: flex; gap: 4px;">
                      <button type="button" class="btn btn-secondary btn-sm" onclick='editAnnouncement(<?php echo json_encode($ann); ?>)' title="Edit Announcement">
                        Edit
                      </button>
                      
                      <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <input type="hidden" name="action" value="toggle_active">
                        <input type="hidden" name="announcement_id" value="<?php echo $ann['id']; ?>">
                        <button type="submit" class="btn btn-secondary btn-sm" title="Toggle active">
                          <?php echo !empty($ann['is_active']) ? 'Disable' : 'Enable'; ?>
                        </button>
                      </form>

                      <form method="POST" onsubmit="return confirm('Delete this announcement?');">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
                        <input type="hidden" name="action" value="delete_announcement">
                        <input type="hidden" name="announcement_id" value="<?php echo $ann['id']; ?>">
                        <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--admin-danger);" title="Delete">
                          &times;
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Form Column (Add / Edit) -->
  <div class="admin-card">
    <div class="admin-card-header">
      <div class="admin-card-title" id="formCardTitle">Add Announcement</div>
    </div>
    <div class="admin-card-body">
      
      <form method="POST" id="annForm">
        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrfToken); ?>">
        <input type="hidden" name="action" id="formAction" value="create_announcement">
        <input type="hidden" name="announcement_id" id="annId" value="">

        <div class="form-group">
          <label class="form-label" for="ann_title">Badge Label (Optional)</label>
          <input type="text" id="ann_title" name="title" class="form-control" placeholder="E.g. Pure Harvest, Special Offer, Free Delivery" oninput="updateLivePreview()">
        </div>

        <div class="form-group">
          <label class="form-label" for="ann_message">Announcement Text <span class="required">*</span></label>
          <textarea id="ann_message" name="message" class="form-control" rows="3" required placeholder="Text displayed in the rotating top banner..." oninput="updateLivePreview()"></textarea>
        </div>

        <div class="form-group">
          <label class="form-label" for="ann_link">Destination Link (Optional)</label>
          <input type="text" id="ann_link" name="link_url" class="form-control" placeholder="shop.php or category.php?slug=perfume" oninput="updateLivePreview()">
          <div class="form-help">Examples: <code>shop.php</code>, <code>category.php?slug=shilajit</code>, <code>#business-opportunity</code></div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label" for="ann_order">Display Sequence</label>
            <input type="number" id="ann_order" name="display_order" class="form-control" value="0">
          </div>

          <div class="form-group">
            <label class="form-label" for="ann_type">Presentation</label>
            <select id="ann_type" name="display_type" class="form-control">
              <option value="scrolling">Rotating Slider</option>
              <option value="static">Static Banner</option>
            </select>
          </div>
        </div>

        <div class="form-group" style="margin-top: 12px;">
          <label style="display: flex; align-items: center; gap: 8px; font-weight: 600; cursor: pointer;">
            <input type="checkbox" id="ann_active" name="is_active" value="1" checked>
            Active &amp; Published on Website
          </label>
        </div>

        <div style="display: flex; gap: 8px; margin-top: 20px;">
          <button type="submit" class="btn btn-primary" id="submitBtn" style="flex: 1;">Save Announcement</button>
          <button type="button" class="btn btn-secondary" id="resetBtn" style="display: none;" onclick="resetAnnForm()">Cancel</button>
        </div>
      </form>

    </div>
  </div>

</div>

<script>
function updateLivePreview() {
  const title = document.getElementById('ann_title').value.trim();
  const msg = document.getElementById('ann_message').value.trim();
  const link = document.getElementById('ann_link').value.trim();

  const prevBadge = document.getElementById('prevBadge');
  const prevMessage = document.getElementById('prevMessage');
  const prevLink = document.getElementById('prevLink');

  if (title) {
    prevBadge.textContent = title;
    prevBadge.style.display = 'inline-block';
  } else {
    prevBadge.style.display = 'none';
  }

  prevMessage.textContent = msg || 'Your announcement text will appear here...';

  if (link) {
    prevLink.style.display = 'inline-block';
  } else {
    prevLink.style.display = 'none';
  }
}

function editAnnouncement(ann) {
  document.getElementById('formCardTitle').textContent = 'Edit Announcement #' + ann.id;
  document.getElementById('formAction').value = 'edit_announcement';
  document.getElementById('annId').value = ann.id;
  document.getElementById('ann_title').value = ann.title || '';
  document.getElementById('ann_message').value = ann.message || '';
  document.getElementById('ann_link').value = ann.link_url || '';
  document.getElementById('ann_order').value = ann.display_order || '0';
  document.getElementById('ann_type').value = ann.display_type || 'scrolling';
  document.getElementById('ann_active').checked = ann.is_active == 1;
  document.getElementById('submitBtn').textContent = 'Update Announcement';
  document.getElementById('resetBtn').style.display = 'inline-flex';
  updateLivePreview();
}

function resetAnnForm() {
  document.getElementById('formCardTitle').textContent = 'Add Announcement';
  document.getElementById('formAction').value = 'create_announcement';
  document.getElementById('annId').value = '';
  document.getElementById('ann_title').value = '';
  document.getElementById('ann_message').value = '';
  document.getElementById('ann_link').value = '';
  document.getElementById('ann_order').value = '0';
  document.getElementById('ann_type').value = 'scrolling';
  document.getElementById('ann_active').checked = true;
  document.getElementById('submitBtn').textContent = 'Save Announcement';
  document.getElementById('resetBtn').style.display = 'none';
  updateLivePreview();
}
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
