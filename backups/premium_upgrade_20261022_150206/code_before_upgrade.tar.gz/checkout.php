<?php
/**
 * Professional Checkout Page - Phase 4 Enhanced
 * Supports guest checkout while prefilling customer details when logged in.
 */

define('ZAFFRAN_APP', true);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/auth.php';
initSession();

$verifiedCart = getVerifiedCart();
$items = $verifiedCart['items'];
$subtotal = $verifiedCart['subtotal'];
$totalCount = $verifiedCart['total_count'];
$shipping = $verifiedCart['shipping'];
$grandTotal = $verifiedCart['grand_total'];
$storeSettings = getStoreSettings();

// If cart is empty, redirect safely to cart.php
if (empty($items)) {
    header('Location: cart.php');
    exit;
}

// Check if customer is authenticated
$isAuthenticated = CustomerAuth::isAuthenticated();
$customer = $isAuthenticated ? CustomerAuth::getCustomer() : null;

// Generate or reuse session idempotency token to prevent double submissions
if (empty($_SESSION['checkout_idempotency_key'])) {
    $_SESSION['checkout_idempotency_key'] = bin2hex(random_bytes(24));
}
$idempotencyKey = $_SESSION['checkout_idempotency_key'];

$pageTitle = 'Secure Checkout | Zaffran Artisanal Store';
$pageDescription = 'Provide delivery details to place your authentic botanical order. Cash on Delivery supported nationwide.';

require_once __DIR__ . '/includes/header.php';
?>

<section class="shop-hero">
  <div class="container shop-hero-inner">
    <nav class="breadcrumb-nav" aria-label="Breadcrumb">
      <ul class="breadcrumb-list" style="justify-content:center;">
        <li><a href="index.php">Home</a></li>
        <li class="breadcrumb-separator">&rsaquo;</li>
        <li><a href="cart.php">Shopping Bag</a></li>
        <li class="breadcrumb-separator">&rsaquo;</li>
        <li class="breadcrumb-current">Secure Checkout</li>
      </ul>
    </nav>
    <h1 class="section-title">Secure Checkout</h1>
    <p class="section-desc">
      Direct on-site order placement. Orders are stored safely in our MySQL database.
    </p>
  </div>
</section>

<main class="checkout-page-section">
  <div class="container">
    
    <form action="place_order.php" method="POST" id="checkout-form" class="checkout-grid">
      <!-- CSRF & Idempotency Hidden Fields -->
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(getCsrfToken()); ?>">
      <input type="hidden" name="idempotency_key" value="<?php echo htmlspecialchars($idempotencyKey); ?>">

      <!-- Left Column: Customer & Delivery Information -->
      <div class="checkout-form-panel">
        
        <?php if ($isAuthenticated && $customer): ?>
          <div style="background-color:var(--color-sage-50); border:1px solid var(--color-sage-200); border-radius:var(--radius-md); padding:12px 18px; margin-bottom:var(--space-xl); display:flex; align-items:center; justify-content:space-between;">
            <div>
              <span style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.06em; color:var(--color-forest-700); font-weight:700;">Verified Customer Account</span>
              <div style="font-weight:700; color:var(--color-forest-900); font-size:0.9375rem;">
                Ordering as <?php echo htmlspecialchars($customer['name']); ?> (<?php echo htmlspecialchars($customer['email']); ?>)
              </div>
            </div>
            <a href="account.php" style="font-size:0.8125rem; color:var(--color-forest-700); font-weight:600; text-decoration:underline;">View Dashboard</a>
          </div>
        <?php else: ?>
          <div style="background-color:var(--color-cream-100); border:1px solid var(--color-border); border-radius:var(--radius-md); padding:12px 18px; margin-bottom:var(--space-xl); display:flex; align-items:center; justify-content:space-between; font-size:0.875rem;">
            <span>Have an existing account with order history?</span>
            <a href="login.php?return=<?php echo urlencode('checkout.php'); ?>" style="font-weight:700; color:var(--color-forest-800); text-decoration:underline;">Sign In with OTP &rarr;</a>
          </div>
        <?php endif; ?>

        <!-- Step 1: Customer Details -->
        <h2 class="checkout-section-title">
          <span class="checkout-step-number">1</span>
          Customer Contact Information
        </h2>

        <div class="form-grid-2col">
          <div class="form-group">
            <label for="customer_name" class="form-label">
              Full Name <span class="required-star">*</span>
            </label>
            <input type="text" id="customer_name" name="customer_name" class="form-control" value="<?php echo htmlspecialchars($customer['name'] ?? ''); ?>" placeholder="e.g. Malik Jahangir" required autocomplete="name">
          </div>

          <div class="form-group">
            <label for="customer_phone" class="form-label">
              Mobile Phone <span class="required-star">*</span>
            </label>
            <input type="tel" id="customer_phone" name="customer_phone" class="form-control" value="<?php echo htmlspecialchars($customer['phone'] ?? ''); ?>" placeholder="0300-1234567" required autocomplete="tel">
          </div>
        </div>

        <div class="form-group">
          <label for="customer_email" class="form-label">
            Email Address <span class="required-star">*</span>
          </label>
          <input type="email" id="customer_email" name="customer_email" class="form-control" value="<?php echo htmlspecialchars($customer['email'] ?? ''); ?>" placeholder="name@example.com" required <?php echo ($isAuthenticated && $customer) ? 'readonly style="background-color:var(--color-cream-100);"' : ''; ?> autocomplete="email">
          <span style="font-size:0.75rem; color:var(--color-text-muted); margin-top:4px;">
            Order confirmation, receipt, and dispatch updates will be sent to this email.
          </span>
        </div>

        <div style="height:1px; background-color:var(--color-border-subtle); margin:var(--space-xl) 0;"></div>

        <!-- Step 2: Shipping & Delivery Address -->
        <h2 class="checkout-section-title">
          <span class="checkout-step-number">2</span>
          Shipping Address (Pakistan)
        </h2>

        <div class="form-group">
          <label for="full_address" class="form-label">
            Full Address <span class="required-star">*</span>
          </label>
          <input type="text" id="full_address" name="full_address" class="form-control" placeholder="Complete physical address (House/Flat, Street, Area, Landmark)" required autocomplete="street-address">
        </div>

        <div class="form-group">
          <label for="delivery_address" class="form-label">
            Street Address / House No. / Building <span class="required-star">*</span>
          </label>
          <input type="text" id="delivery_address" name="delivery_address" class="form-control" placeholder="House 12, Street 4, Gulberg III" required>
        </div>

        <div class="form-grid-2col">
          <div class="form-group">
            <label for="city" class="form-label">
              City / Town <span class="required-star">*</span>
            </label>
            <input type="text" id="city" name="city" class="form-control" placeholder="e.g. Lahore, Kot Addu, Karachi" required autocomplete="address-level2">
          </div>

          <div class="form-group">
            <label for="province" class="form-label">
              Province <span class="required-star">*</span>
            </label>
            <select id="province" name="province" class="form-control" required autocomplete="address-level1">
              <option value="" disabled selected>Select Province</option>
              <option value="Punjab">Punjab</option>
              <option value="Sindh">Sindh</option>
              <option value="Khyber Pakhtunkhwa">Khyber Pakhtunkhwa</option>
              <option value="Balochistan">Balochistan</option>
              <option value="Islamabad Capital Territory">Islamabad Capital Territory</option>
              <option value="Gilgit-Baltistan">Gilgit-Baltistan</option>
              <option value="Azad Kashmir">Azad Kashmir</option>
            </select>
          </div>
        </div>

        <div class="form-grid-2col">
          <div class="form-group">
            <label for="postal_code" class="form-label">
              Postal Code (Optional)
            </label>
            <input type="text" id="postal_code" name="postal_code" class="form-control" placeholder="e.g. 54000" autocomplete="postal-code">
          </div>

          <div class="form-group">
            <label for="notes" class="form-label">
              Special Delivery Instructions (Optional)
            </label>
            <input type="text" id="notes" name="notes" class="form-control" placeholder="Near landmark, call upon arrival, etc.">
          </div>
        </div>

        <div style="height:1px; background-color:var(--color-border-subtle); margin:var(--space-xl) 0;"></div>

        <!-- Step 3: Payment Method -->
        <h2 class="checkout-section-title">
          <span class="checkout-step-number">3</span>
          Payment Method
        </h2>

        <?php $codEnabled = ($storeSettings['enable_cod'] ?? '1') === '1'; ?>

        <?php if ($codEnabled): ?>
          <label class="payment-option-card selected">
            <input type="radio" name="payment_method" value="cod" checked class="payment-option-radio">
            <div class="payment-option-details">
              <strong>Cash on Delivery (COD)</strong>
              <span>Pay in cash directly to courier agent upon secure delivery of your package.</span>
            </div>
          </label>
        <?php else: ?>
          <div style="padding:14px; background-color:#fee2e2; border-radius:var(--radius-md); color:#b91c1c; font-size:0.875rem;">
            Cash on Delivery is currently disabled in store configuration. Please contact customer support.
          </div>
        <?php endif; ?>

      </div>

      <!-- Right Column: Order Summary & Place Order Action -->
      <aside class="checkout-summary-sidebar">
        <div class="cart-summary-card">
          
          <h2 class="summary-heading">Review Order (<?php echo (int)$totalCount; ?>)</h2>

          <!-- Mini Order Items Preview -->
          <ul class="order-items-preview">
            <?php foreach ($items as $item): ?>
              <li class="order-item-preview-row">
                <img src="<?php echo htmlspecialchars($item['image_url']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="order-item-preview-thumb">
                <div class="order-item-preview-meta">
                  <span class="order-item-preview-title"><?php echo htmlspecialchars($item['name']); ?></span>
                  <span class="order-item-preview-qty">Qty: <?php echo (int)$item['quantity']; ?> &times; <?php echo $item['formatted_unit_price']; ?></span>
                </div>
                <div class="order-item-preview-price">
                  <?php echo $item['formatted_total_price']; ?>
                </div>
              </li>
            <?php endforeach; ?>
          </ul>

          <!-- Pricing Calculations -->
          <div class="summary-row">
            <span>Items Subtotal</span>
            <strong><?php echo $verifiedCart['formatted_subtotal']; ?></strong>
          </div>

          <div class="summary-row">
            <div>
              <span>Standard Delivery</span>
              <?php if ($shipping['is_free']): ?>
                <span class="summary-badge-free" style="margin-left:4px;">FREE</span>
              <?php endif; ?>
            </div>
            <span><?php echo htmlspecialchars($shipping['formatted_fee']); ?></span>
          </div>

          <div class="summary-row grand-total">
            <span>Grand Total</span>
            <strong style="color:var(--color-forest-900);"><?php echo $verifiedCart['formatted_grand_total']; ?></strong>
          </div>

          <!-- Final Submit Order Button -->
          <button type="submit" class="btn btn-primary summary-action-btn" id="place-order-submit-btn" <?php echo !$codEnabled ? 'disabled' : ''; ?>>
            Confirm &amp; Place Order
          </button>

          <p style="font-size:0.75rem; color:var(--color-text-muted); text-align:center; margin-top:12px; line-height:1.5;">
            By confirming, your order will be recorded in our system. You will receive an instant order number and confirmation receipt.
          </p>

          <div class="cart-assurance-list" style="margin-top:var(--space-md);">
            <div class="cart-assurance-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              <span>Authentic products directly from Zaffran</span>
            </div>
            <div class="cart-assurance-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
              <span>Estimated Delivery: 2 &ndash; 4 Business Days</span>
            </div>
          </div>

        </div>
      </aside>

    </form>

  </div>
</main>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
