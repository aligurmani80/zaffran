/**
 * Zaffran Signature Hero 3D Animated Typewriter (Zevyon-Style Dedicated Engine)
 *
 * Requirements:
 * 1. Automatically type letters one by one.
 * 2. Display the complete word briefly (1400ms).
 * 3. Automatically erase letters one by one.
 * 4. After the word is fully erased, PAUSE FOR EXACTLY 1 SECOND (1000ms).
 * 5. Start writing the word again.
 * 6. Repeat smoothly.
 * 7. Multi-word cycling across our signature collections if configured.
 * 8. Respect reduced-motion accessibility preferences.
 */

(function () {
  'use strict';

  function initSignatureTypewriter() {
    const wordEl = document.querySelector('.js-typewriter-target');
    if (!wordEl) return;

    // Respect reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    // Words to rotate through smoothly
    let words = ['Perfumes', 'Shilajit', 'Zaffran', 'Perfume Oils'];
    const initialWord = wordEl.getAttribute('data-word');
    if (initialWord && words.indexOf(initialWord) === -1) {
      words.unshift(initialWord);
    }

    if (prefersReducedMotion) {
      wordEl.textContent = words[0];
      return;
    }

    let wordIndex = 0;
    let charIndex = 0;
    let isErasing = false;
    let timerId = null;

    function typeLoop() {
      const currentWord = words[wordIndex];

      if (!isErasing) {
        // Step 1: Type letters automatically one by one
        charIndex++;
        wordEl.textContent = currentWord.substring(0, charIndex);

        if (charIndex >= currentWord.length) {
          // Step 2: Hold complete word briefly (1400ms)
          isErasing = true;
          timerId = setTimeout(typeLoop, 1400);
          return;
        }

        // Typing speed: natural 100-130ms per character
        const typingSpeed = 100 + Math.random() * 30;
        timerId = setTimeout(typeLoop, typingSpeed);
      } else {
        // Step 3: Erase letters one by one
        charIndex--;
        wordEl.textContent = currentWord.substring(0, charIndex);

        if (charIndex <= 0) {
          // Step 4: Fully erased. PAUSE FOR EXACTLY 1000ms (1 SECOND)
          isErasing = false;
          wordIndex = (wordIndex + 1) % words.length;
          
          timerId = setTimeout(function () {
            // Step 5: Start typing again
            typeLoop();
          }, 1000); // EXACT 1000ms PAUSE REQUIREMENT
          return;
        }

        // Erasing speed: 60ms per character
        timerId = setTimeout(typeLoop, 60);
      }
    }

    // Initial short pause before start
    timerId = setTimeout(typeLoop, 350);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSignatureTypewriter);
  } else {
    initSignatureTypewriter();
  }
})();
