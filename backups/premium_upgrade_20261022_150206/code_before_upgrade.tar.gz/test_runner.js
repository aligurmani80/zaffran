const http = require('http');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

async function main() {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'chrome-prof-'));
  const chrome = spawn('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', [
    '--headless=new',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    '--user-data-dir=' + tempDir,
    '--remote-debugging-port=9444',
    'http://localhost/zaffran/index.php'
  ]);

  // Wait for port
  let connected = false;
  for (let i = 0; i < 20; i++) {
    try {
      await new Promise(r => setTimeout(r, 300));
      const res = await new Promise((resolve, reject) => {
        const req = http.get('http://127.0.0.1:9444/json', resolve);
        req.on('error', reject);
      });
      connected = true;
      break;
    } catch (e) {}
  }

  if (!connected) {
    console.error('Failed to connect to chrome on 9444');
    chrome.kill();
    process.exit(1);
  }

  const tabs = await new Promise((resolve, reject) => {
    http.get('http://127.0.0.1:9444/json', res => {
      let d = '';
      res.on('data', chunk => d += chunk);
      res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });

  const pageTab = tabs.find(t => t.type === 'page');
  const ws = new WebSocket(pageTab.webSocketDebuggerUrl);
  await new Promise(res => ws.addEventListener('open', res));

  function sendCommand(method, params = {}) {
    return new Promise((resolve) => {
      const id = Math.floor(Math.random() * 1000000);
      const handler = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.id === id) {
          ws.removeEventListener('message', handler);
          resolve(msg.result);
        }
      };
      ws.addEventListener('message', handler);
      ws.send(JSON.stringify({ id, method, params }));
    });
  }

  await sendCommand('Page.enable');

  async function testPageWidth(url, width) {
    await sendCommand('Page.navigate', { url });
    await new Promise(r => setTimeout(r, 600));
    await sendCommand('Emulation.setDeviceMetricsOverride', {
      width,
      height: 900,
      deviceScaleFactor: 1,
      mobile: width < 1024
    });
    await new Promise(r => setTimeout(r, 400));

    const evalRes = await sendCommand('Runtime.evaluate', {
      expression: `
        (() => {
          const grid = document.querySelector('.product-grid');
          if (!grid) return { error: 'No product grid found' };
          const computed = window.getComputedStyle(grid);
          const cards = Array.from(grid.querySelectorAll('.product-card'));
          const colDef = computed.gridTemplateColumns;
          const colsCount = colDef.split(' ').length;
          const gap = computed.gap;
          const docWidth = document.documentElement.scrollWidth;
          const clientWidth = document.documentElement.clientWidth;
          const hasHorizontalScroll = docWidth > clientWidth;
          
          const cardBoxes = cards.map((c, i) => {
            const rect = c.getBoundingClientRect();
            const btn = c.querySelector('.js-add-to-cart');
            return {
              i,
              x: Math.round(rect.x),
              y: Math.round(rect.y),
              w: Math.round(rect.width),
              h: Math.round(rect.height),
              hasBtn: !!btn
            };
          });

          // Group into rows
          const rows = {};
          cardBoxes.forEach(c => {
            const rowKey = Math.round(c.y / 25) * 25;
            if (!rows[rowKey]) rows[rowKey] = [];
            rows[rowKey].push(c);
          });
          const rowCounts = Object.values(rows).map(r => r.length);

          return {
            colsCount,
            colDef,
            gap,
            totalCards: cards.length,
            rowCounts,
            hasHorizontalScroll,
            cardWidths: cardBoxes.slice(0, 3).map(c => c.w),
            btnFunctionalCheck: cardBoxes.every(c => c.hasBtn)
          };
        })()
      `,
      returnByValue: true
    });

    return evalRes.result.value;
  }

  const widths = [320, 360, 390, 430, 768, 1024, 1440];
  const pages = [
    { name: 'Homepage (Featured)', url: 'http://localhost/zaffran/index.php' },
    { name: 'Shop Page', url: 'http://localhost/zaffran/shop.php' },
    { name: 'Category Page', url: 'http://localhost/zaffran/category.php?slug=saffron' },
    { name: 'Related Products (Single Product)', url: 'http://localhost/zaffran/product.php?slug=kashmir-super-mongra-saffron' }
  ];

  for (const p of pages) {
    console.log('\n--- ' + p.name + ' ---');
    for (const w of widths) {
      const res = await testPageWidth(p.url, w);
      console.log('Viewport ' + w + 'px: Cols=' + res.colsCount + ' | Rows=' + JSON.stringify(res.rowCounts) + ' | Gap=' + res.gap + ' | HScroll=' + res.hasHorizontalScroll + ' | CardWidth=' + res.cardWidths[0] + 'px | AllAddButtonsPresent=' + res.btnFunctionalCheck);
    }
  }

  ws.close();
  chrome.kill();
  try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch (e) {}
}

main().catch(console.error);
